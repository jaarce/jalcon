#!/usr/bin/env python
import core
import sys

if __name__ == "__main__":
    command = sys.argv
    core.execute_from_command_line(command)
